export class DevSharedConsts {
	static HOT_RELOAD_SIGNAL_PATH = "js-dev/hot-reload.json";
}
